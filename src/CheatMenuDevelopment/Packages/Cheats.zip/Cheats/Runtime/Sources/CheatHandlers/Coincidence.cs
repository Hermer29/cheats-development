﻿namespace Hermer29.Cheats
{
    public struct Coincidence
    {
        public int EndPosition;
        public ICheatHandler Handler;
    }
}