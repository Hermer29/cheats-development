﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace Hermer29.Cheats
{
    internal class RootView : MonoBehaviour, ITickService
    {
        [field: SerializeField] public CheatsView CheatsView { get; private set; }
        [field: SerializeField] public PredictionsView PredictionsView { get; private set; }
        
        private List<ITickable> _tickables = new List<ITickable>();

        private void Start()
        {
            DontDestroyOnLoad(gameObject);
        }

        public void Integrate(ITickable tickable) => _tickables.Add(tickable);

        private void Update()
        {
            foreach (ITickable tickable in _tickables) 
                tickable.Tick(Time.deltaTime);
        }
    }
}