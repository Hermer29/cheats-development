﻿namespace Hermer29.Cheats
{
    internal interface ITickService
    {
        void Integrate(ITickable tickable);
    }
}