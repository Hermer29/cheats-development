﻿namespace Hermer29.Cheats
{
    internal interface ITickable
    {
        void Tick(float deltaTime);
    }
}